//>>built
// wrapped by build app
define("dojox/jtlc/CHT/instance/main", ["dojo","dijit","dojox"], function(dojo,dijit,dojox){
dojo.provide( "dojox.jtlc.CHT.instance" );


});
